<?php declare(strict_types=1);

namespace Uploadcare\Serializer\Exceptions;

class ClassNotFoundException extends \RuntimeException
{
}
