<?php declare(strict_types=1);

namespace Uploadcare\Serializer\Exceptions;

class MethodNotFoundException extends \RuntimeException
{
}
