<?php declare(strict_types=1);

namespace Uploadcare\AuthUrl\Token;

class TokenException extends \RuntimeException
{
}
