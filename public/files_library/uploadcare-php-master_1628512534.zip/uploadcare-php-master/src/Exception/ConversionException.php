<?php declare(strict_types=1);

namespace Uploadcare\Exception;

class ConversionException extends \RuntimeException
{
}
